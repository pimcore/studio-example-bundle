
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_studio_example_bundle = "/bundles/pimcorestudioexample/build/fc755267691a/static/js/remoteEntry.js"

      
    