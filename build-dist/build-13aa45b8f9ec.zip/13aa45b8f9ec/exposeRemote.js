
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_studio_example_bundle = "/bundles/pimcorestudioexample/build/13aa45b8f9ec/static/js/remoteEntry.js"

      
    