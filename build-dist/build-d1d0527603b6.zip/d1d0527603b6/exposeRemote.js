
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_studio_example_bundle = "/bundles/pimcorestudioexample/build/d1d0527603b6/static/js/remoteEntry.js"

      
    