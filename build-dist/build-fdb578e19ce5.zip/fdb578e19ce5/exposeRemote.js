
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_studio_example_bundle = "/bundles/pimcorestudioexample/build/fdb578e19ce5/static/js/remoteEntry.js"

      
    